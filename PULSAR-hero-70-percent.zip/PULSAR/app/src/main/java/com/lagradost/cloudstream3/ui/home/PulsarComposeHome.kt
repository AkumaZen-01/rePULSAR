package com.lagradost.cloudstream3.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.lagradost.cloudstream3.R
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.APIHolder
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val PulsarBg = Color(0xFF05060A)
private val PulsarPurple = Color(0xFF9B65F5)
private val PulsarGlass = Color(0xD9161722)

@Composable
fun PulsarComposeHome(
    sections: List<HomeViewModel.ExpandableHomepageList>,
    onItemClick: (SearchResponse) -> Unit,
    onSearch: () -> Unit,
    onSourceClick: () -> Unit,
    currentSource: String,
    onTab: (String) -> Unit,
) {
    val featuredItems = sections.flatMap { it.list.list }.distinctBy { it.url }.take(5)
    val heroPager = rememberPagerState(pageCount = { featuredItems.size.coerceAtLeast(1) })
    val listState = rememberLazyListState()
    // SearchResponse intentionally carries no logo URL. Resolve the provider's native
    // LoadResponse metadata so the hero can reuse the same logoUrl CloudStream uses.
    val heroLogoUrls = remember { mutableStateMapOf<String, String?>() }
    val heroLogoResolved = remember { mutableStateMapOf<String, Boolean>() }

    LaunchedEffect(featuredItems) {
        featuredItems.forEach { item ->
            if (heroLogoResolved[item.url] != true) {
                val logo = withContext(Dispatchers.IO) {
                    runCatching {
                        APIHolder.allProviders.firstOrNull { it.name == item.apiName }
                            ?.load(item.url)?.logoUrl
                    }.getOrNull()
                }
                heroLogoUrls[item.url] = logo?.takeIf { it.isNotBlank() }
                heroLogoResolved[item.url] = true
            }
        }
    }
    val headerAlpha by animateFloatAsState(if (listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 90) 1f else 0f, label = "pulsar-header-fade")

    LaunchedEffect(featuredItems.size) {
        if (featuredItems.size > 1) {
            while (true) {
                delay(5_000L)
                heroPager.animateScrollToPage((heroPager.currentPage + 1) % featuredItems.size)
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = PulsarBg) {
        Box(Modifier.fillMaxSize()) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val heroHeight = maxHeight * 0.7f
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 112.dp)
                ) {
                if (featuredItems.isNotEmpty()) {
                    item {
                        HorizontalPager(
                            state = heroPager,
                            modifier = Modifier.fillMaxWidth().height(heroHeight)
                        ) { page ->
                            val featured = featuredItems[page]
                            Box(Modifier.fillMaxSize()) {
                                AsyncImage(
                                    model = featured.posterUrl,
                                    contentDescription = featured.name,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                // Cinematic fade: strong at the top for the wordmark and at the
                                // bottom to blend the artwork into the black content background.
                                Box(
                                    Modifier.fillMaxSize().background(
                                        Brush.verticalGradient(
                                            colorStops = arrayOf(
                                                0.0f to Color(0xF005060A),
                                                0.13f to Color(0x2205060A),
                                                0.48f to Color.Transparent,
                                                0.72f to Color(0x6605060A),
                                                1.0f to PulsarBg
                                            )
                                        )
                                    )
                                )
                                Column(
                                    Modifier.align(Alignment.BottomStart).fillMaxWidth()
                                        .padding(start = 24.dp, end = 24.dp, bottom = 38.dp)
                                ) {
                                    val heroLogo = heroLogoUrls[featured.url]
                                    AnimatedContent(
                                        targetState = heroLogo,
                                        transitionSpec = {
                                            (fadeIn(tween(420)) togetherWith fadeOut(tween(300)))
                                        },
                                        label = "hero-title-art-transition"
                                    ) { logoUrl ->
                                        if (!logoUrl.isNullOrBlank()) {
                                            AsyncImage(
                                                model = logoUrl,
                                                contentDescription = featured.name,
                                                modifier = Modifier.fillMaxWidth(0.82f)
                                                    .heightIn(max = 112.dp)
                                                    .graphicsLayer {
                                                        scaleX = 1.025f
                                                        scaleY = 1.025f
                                                        translationY = -3f
                                                    },
                                                contentScale = ContentScale.Fit
                                            )
                                        } else {
                                            Text(
                                                featured.name,
                                                modifier = Modifier.graphicsLayer {
                                                    scaleX = 1.025f
                                                    scaleY = 1.025f
                                                    translationY = -3f
                                                },
                                                color = Color.White,
                                                fontSize = 35.sp,
                                                fontWeight = FontWeight.Black,
                                                lineHeight = 39.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Text(
                                        "${featured.type?.name ?: "Movie"}  •  ${featured.apiName}",
                                        color = Color(0xFFB9BBC5),
                                        fontSize = 14.sp,
                                        modifier = Modifier.padding(top = 7.dp, bottom = 20.dp)
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier.weight(1f).height(54.dp)
                                                .shadow(14.dp, RoundedCornerShape(30.dp))
                                                .clip(RoundedCornerShape(30.dp))
                                                .background(Brush.verticalGradient(listOf(Color(0xFF6A2A91), Color(0xFF35154D), Color(0xFF1B1028))))
                                                .clickable { onItemClick(featured) }
                                                .padding(horizontal = 18.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("▶", color = Color(0xFFD9A5FF), fontSize = 18.sp)
                                                Spacer(Modifier.width(10.dp))
                                                Text("Play", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                            }
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        OutlinedButton(
                                            onClick = { onItemClick(featured) },
                                            modifier = Modifier.weight(1f).height(54.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF8C8D99)),
                                            shape = RoundedCornerShape(12.dp)
                                        ) { Text("ⓘ  Info", fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
                                    }
                                    if (featuredItems.size > 1) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(top = 24.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            repeat(featuredItems.size) { index ->
                                                Box(
                                                    Modifier.padding(horizontal = 4.dp)
                                                        .width(if (heroPager.currentPage == index) 24.dp else 8.dp)
                                                        .height(8.dp)
                                                        .clip(CircleShape)
                                                        .background(if (heroPager.currentPage == index) Color.White else Color(0xFF777984))
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                sections.forEachIndexed { index, section ->
                    if (section.list.list.isNotEmpty()) {
                        item(key = "heading-$index") {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 20.dp, bottom = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(section.list.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Text("→", color = PulsarPurple, fontSize = 25.sp)
                            }
                        }
                        item(key = "row-$index") {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                section.list.list.forEach { result ->
                                    Column(Modifier.width(142.dp).clickable { onItemClick(result) }) {
                                        AsyncImage(
                                            model = result.posterUrl,
                                            contentDescription = result.name,
                                            modifier = Modifier.fillMaxWidth().height(205.dp)
                                                .clip(RoundedCornerShape(13.dp)).background(Color(0xFF171821)),
                                            contentScale = ContentScale.Crop
                                        )
                                        Text(result.name, color = Color.White, fontSize = 13.sp, maxLines = 2,
                                            modifier = Modifier.padding(start = 4.dp, top = 7.dp, end = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                }
            }

            // Home-only source selector; the shared navigation remains consistent elsewhere.
            Row(
                modifier = Modifier.align(Alignment.BottomStart)
                    .padding(start = 14.dp, bottom = 8.dp)
                    .shadow(12.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF47206E), Color(0xFF21112F), Color(0xFF160D22))))
                    .clickable { onSourceClick() }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("☷", color = Color(0xFFD9A5FF), fontSize = 20.sp)
                Spacer(Modifier.width(8.dp))
                Text(currentSource, color = Color.White, fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(6.dp))
                Text("⌄", color = Color(0xFFD9A5FF), fontSize = 16.sp)
            }

            // Geometric PULSAR wordmark: purple liquid-glass gradient stays on the letters.
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xE805060A), Color(0x7705060A), Color.Transparent)))
                    .padding(start = 24.dp, end = 22.dp, top = 15.dp, bottom = 30.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.pulsar_wordmark),
                    contentDescription = "PULSAR",
                    modifier = Modifier.width(132.dp).height(39.dp).alpha(headerAlpha),
                    contentScale = ContentScale.FillBounds
                )
                Spacer(Modifier.weight(1f))
                Text("⌕", color = Color.White, fontSize = 34.sp,
                    modifier = Modifier.clickable { onSearch() }.padding(horizontal = 8.dp))
            }

        }
    }
}

