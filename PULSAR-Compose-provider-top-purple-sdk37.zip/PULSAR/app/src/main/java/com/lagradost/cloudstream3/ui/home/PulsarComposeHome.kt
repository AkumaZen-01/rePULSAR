package com.lagradost.cloudstream3.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.lagradost.cloudstream3.SearchResponse
import kotlinx.coroutines.delay

private val PulsarBg = Color(0xFF08080D)
private val PulsarPanel = Color(0xFF15141D)
private val PulsarPurple = Color(0xFF9B65F5)

@Composable
fun PulsarComposeHome(
    sections: List<HomeViewModel.ExpandableHomepageList>,
    onItemClick: (SearchResponse) -> Unit,
    onSearch: () -> Unit,
    onProvider: () -> Unit,
    providerName: String,
    onTab: (String) -> Unit,
) {
    // The selected provider supplies the content. Display five distinct real titles
    // in the hero carousel rather than repeating a single featured title.
    val featuredItems = sections.flatMap { it.list.list }.distinctBy { it.url }.take(5)
    val heroPager = rememberPagerState(pageCount = { featuredItems.size })

    LaunchedEffect(featuredItems.size) {
        if (featuredItems.size > 1) {
            while (true) {
                delay(5_000L)
                heroPager.animateScrollToPage((heroPager.currentPage + 1) % featuredItems.size)
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = PulsarBg) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            // MainActivity already owns the app's bottom navigation. Do not draw
            // another Compose navigation row over it.
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PULSAR", color = PulsarPurple, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                    Spacer(Modifier.weight(1f))
                    Text("⌕", color = Color.White, fontSize = 32.sp, modifier = Modifier.clickable { onSearch() }.padding(horizontal = 14.dp))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(PulsarPurple.copy(alpha = 0.20f))
                            .clickable { onProvider() }
                            .padding(horizontal = 15.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("☰", color = PulsarPurple, fontSize = 18.sp)
                        Spacer(Modifier.width(9.dp))
                        Text(
                            providerName.ifBlank { "Select provider" },
                            color = PulsarPurple,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            if (featuredItems.isNotEmpty()) {
                item {
                    HorizontalPager(
                        state = heroPager,
                        modifier = Modifier.fillMaxWidth().height(440.dp)
                    ) { page ->
                        val featured = featuredItems[page]
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = featured.posterUrl,
                                contentDescription = featured.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x55000000), PulsarBg))))
                            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 24.dp, vertical = 25.dp)) {
                                Text(featured.name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 38.sp, maxLines = 2)
                                Text("${featured.type?.name ?: "Anime"}  •  ${featured.apiName}", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = { onItemClick(featured) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black), shape = RoundedCornerShape(9.dp)) {
                                        Text("▶  Play", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    OutlinedButton(onClick = { onItemClick(featured) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), shape = RoundedCornerShape(9.dp)) {
                                        Text("ⓘ  Info")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            sections.forEachIndexed { index, section ->
                if (section.list.list.isNotEmpty()) {
                    item(key = "heading-$index") {
                        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(section.list.name, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text("→", color = PulsarPurple, fontSize = 25.sp)
                        }
                    }
                    item(key = "row-$index") {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            section.list.list.forEach { result ->
                                Column(Modifier.width(142.dp).clickable { onItemClick(result) }) {
                                    AsyncImage(
                                        model = result.posterUrl,
                                        contentDescription = result.name,
                                        modifier = Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(13.dp)).background(PulsarPanel),
                                        contentScale = ContentScale.Crop
                                    )
                                    Text(result.name, color = Color.White, fontSize = 13.sp, maxLines = 2, modifier = Modifier.padding(start = 4.dp, top = 7.dp, end = 4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
