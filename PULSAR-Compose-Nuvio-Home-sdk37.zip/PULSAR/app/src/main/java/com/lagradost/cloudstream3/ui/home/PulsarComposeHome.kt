package com.lagradost.cloudstream3.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.lagradost.cloudstream3.SearchResponse

private val PulsarBg = Color(0xFF08080D)
private val PulsarPanel = Color(0xFF15141D)
private val PulsarPurple = Color(0xFF9B65F5)

@Composable
fun PulsarComposeHome(
    sections: List<HomeViewModel.ExpandableHomepageList>,
    onItemClick: (SearchResponse) -> Unit,
    onSearch: () -> Unit,
    onProvider: () -> Unit,
    onTab: (String) -> Unit,
) {
    val featured = sections.firstOrNull()?.list?.list?.firstOrNull()
    Surface(Modifier.fillMaxSize(), color = PulsarBg) {
        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 104.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("PULSAR", color = PulsarPurple, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                        Spacer(Modifier.weight(1f))
                        Text("⌕", color = Color.White, fontSize = 32.sp, modifier = Modifier.clickable { onSearch() }.padding(horizontal = 14.dp))
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(50)).background(PulsarPanel).clickable { onProvider() }, contentAlignment = Alignment.Center) {
                            Text("◉", color = PulsarPurple, fontSize = 22.sp)
                        }
                    }
                }
                if (featured != null) {
                    item {
                        Box(Modifier.fillMaxWidth().height(440.dp)) {
                            AsyncImage(
                                model = featured.posterUrl,
                                contentDescription = featured.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x55000000), PulsarBg))))
                            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 24.dp, vertical = 25.dp)) {
                                Text(featured.name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 38.sp, maxLines = 2)
                                Text("${featured.type?.name ?: "Movie"}  •  ${featured.apiName}", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = { onItemClick(featured) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black), shape = RoundedCornerShape(9.dp)) {
                                        Text("▶  Play", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    OutlinedButton(onClick = { onItemClick(featured) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), shape = RoundedCornerShape(9.dp)) { Text("ⓘ  Info") }
                                }
                            }
                        }
                    }
                }
                sections.forEachIndexed { index, section ->
                    if (section.list.list.isNotEmpty()) {
                        item(key = "heading-$index") {
                            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(section.list.name, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                Text("→", color = PulsarPurple, fontSize = 25.sp)
                            }
                        }
                        item(key = "row-$index") {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                section.list.list.forEach { result ->
                                    Column(Modifier.width(142.dp).clickable { onItemClick(result) }) {
                                        AsyncImage(
                                            model = result.posterUrl,
                                            contentDescription = result.name,
                                            modifier = Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(13.dp)).background(PulsarPanel),
                                            contentScale = ContentScale.Crop
                                        )
                                        Text(result.name, color = Color.White, fontSize = 13.sp, maxLines = 2, modifier = Modifier.padding(start = 4.dp, top = 7.dp, end = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF014131A)).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("⌂" to "Home", "⌕" to "Search", "▣" to "Library", "↓" to "Downloads", "⚙" to "Settings").forEach { (symbol, label) ->
                    Column(Modifier.clip(RoundedCornerShape(18.dp)).clickable { onTab(label) }.padding(horizontal = 13.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(symbol, color = if (label == "Home") PulsarPurple else Color.White, fontSize = 25.sp)
                        Text(label, color = if (label == "Home") PulsarPurple else Color.LightGray, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
