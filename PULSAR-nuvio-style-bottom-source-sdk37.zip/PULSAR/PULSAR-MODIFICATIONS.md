# PULSAR modification notes

- Android application ID changed to `app.pulsar.media`.
- Launcher/app display name changed to `PULSAR`.
- Main mobile navigation's Home label changed to Discover.
- Home hero header now includes a PULSAR wordmark.
- Base dark palette and primary accent shifted toward purple.
- Original CloudStream source packages, plugin architecture, playback, downloads, and GPL-3.0 notices are retained.

This is an initial branded fork, not yet a complete pixel-for-pixel Stremio mobile UI replacement.
The current home content, detail screens, search, and player still use upstream CloudStream layouts where not listed above.
