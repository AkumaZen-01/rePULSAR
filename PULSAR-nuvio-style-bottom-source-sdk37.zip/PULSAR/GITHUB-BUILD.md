# Build PULSAR on GitHub using an Android phone

This is the phone-friendly route: upload one ZIP file, then add one small workflow file.

## 1. Create a GitHub repository
1. Open https://github.com/ in your phone browser and sign in.
2. Create a new repository named `PULSAR`. A private repository is fine.

## 2. Upload the source ZIP
1. Download `PULSAR-source.zip` from this ChatGPT conversation to your phone.
2. In your new GitHub repository, choose **Add file → Upload files**.
3. Upload the file named `PULSAR-source.zip` (do not extract it).
4. Commit the upload to the `main` branch.

## 3. Add the build workflow
1. In the repository, choose **Add file → Create new file**.
2. For the filename enter exactly `.github/workflows/build-pulsar.yml`.
3. Open `GITHUB-BUILD-WORKFLOW.txt` from the source ZIP, copy all its contents, and paste them into the GitHub editor.
4. Commit the new file to `main`.

## 4. Run the build
1. Open the repository's **Actions** tab.
2. Select **Build PULSAR APK**.
3. Tap **Run workflow** and confirm.
4. Wait for the run to finish successfully. The first build can take several minutes.

## 5. Download the APK
1. Open the completed workflow run.
2. Scroll to **Artifacts** and download `PULSAR-APK`.
3. Extract that downloaded ZIP and tap the APK to install it.

The workflow builds `:app:assembleStableRelease` on GitHub-hosted Ubuntu and uploads the APK as a 14-day artifact.

## Important
- The APK is an unsigned release build. For publishing or distributing it, sign it with your own private keystore. Never upload a keystore or passwords to GitHub.
- A successful compile does not mean the complete Stremio-inspired UI redesign is finished.
- CloudStream does not bundle video sources by default; configure compatible lawful extensions separately.
- PULSAR is based on GPL-3.0-licensed CloudStream. Preserve the license and source notices.
