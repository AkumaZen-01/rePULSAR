# Building PULSAR APK

## Requirements
- Android Studio with Android SDK installed
- JDK 17 (the project configures a Java 17 toolchain)
- Android SDK Platform 37 (compileSdk 37)
- Internet access for Gradle and Maven dependencies on the first build

## Android Studio
1. Extract `PULSAR-source.zip`.
2. Open the extracted `PULSAR` folder in Android Studio.
3. In SDK Manager, install Android SDK Platform 37 and the Android SDK Build-Tools version requested by the build.
4. Set Gradle JDK to JDK 17 in Settings > Build, Execution, Deployment > Build Tools > Gradle.
5. Wait for Gradle sync, then choose the `stableRelease` variant.
6. Run Build > Build Bundle(s) / APK(s) > Build APK(s), or use the terminal command below.

## Command line

Linux/macOS:
```bash
./gradlew :app:assembleStableRelease
```

Windows:
```bat
gradlew.bat :app:assembleStableRelease
```

The unsigned release APK is normally written to:
`app/build/outputs/apk/stable/release/app-stable-release-unsigned.apk`

Sign the APK with your own release keystore before distributing it. Do not share your keystore or passwords.

## Notes
- The first build downloads Gradle and project dependencies, so it requires working internet.
- This is an initial branded CloudStream fork. It does not yet implement a full Stremio UI redesign.
- CloudStream does not ship with media sources by default; compatible lawful extensions must be configured separately.
- PULSAR is based on GPL-3.0-licensed CloudStream. Preserve the license and source notices when redistributing.
